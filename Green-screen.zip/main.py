# - Green Screen - Linda Mansour -

import image

def green_screen(file_front, file_back, ch, cd):
    
  image_a  = image.FileImage(file_front)
  image_b  = image.FileImage(file_back)
  
  width_a  = image_a.get_width() 
  height_a = image_a.get_height()
   
  width_b  = image_b.get_width() 
  height_b = image_b.get_height()
  
  new_image = image_a

  if (width_a * height_a) == (width_b * height_b):

    if ch == 1:
      for row in range(height_a):
        for col in range(width_a):
          v = image_a.get_pixel(col, row)
          vb = image_b.get_pixel(col, row)
          
          if v.red > (cd * v.green) and v.red > (cd * v.blue):
            new_pixel = vb
          else:
            new_pixel = v
          new_image.set_pixel(col, row , new_pixel)
      new_image.save(file_front[0:file_front.find(".")] + "_" + file_back[0:file_back.find(".")] + ".jpg")
      
    if ch == 2:
      for row in range(height_a):
        for col in range (width_a):
          v = image_a.get_pixel(col, row)
          vb = image_b.get_pixel(col, row)
    
          if v.green > (cd * v.red) and v.green > (cd * v.blue): 
            new_pixel = vb
          else:
            new_pixel = v
          new_image.set_pixel(col, row , new_pixel)
      new_image.save(file_front[0:file_front.find(".")] + "_" + file_back[0:file_back.find(".")] + ".jpg")
    
    if ch == 3:
      for row in range(height_a):
        for col in range (width_a):
          v = image_a.get_pixel(col, row)
          vb = image_b.get_pixel(col, row)
  
          if v.blue > (cd * v.red) and v.blue > (cd * v.green):
            new_pixel = vb
          else:
            new_pixel = v
          new_image.set_pixel(col, row , new_pixel)
      new_image.save(file_front[0:file_front.find(".")] + "_" + file_back[0:file_back.find(".")] + ".jpg")

  else:
    print('wrong dimensions')
if __name__ == '__main__':
  front = 'tiger.jpg'
  back = 'colorBackground.jpeg'
  green_screen(front, back, 2, 1.5)

  front = 'catred.jpg'
  back = 'purpleBackground.jpg'
  green_screen(front, back, 1, 2.5)

  front = 'dino.jpg'
  back = 'bigben.jpg'
  green_screen(front, back, 3, 1.3)

  front = 'puppy.jpg'
  back = 'space.jpeg'
  green_screen(front, back, 2, 1.1)

  front = 'lion.jpg'
  back = 'city.jpg'
  green_screen(front, back, 2, 1.2)

  front = 'lion.jpg';
  back = 'colorBackground.jpeg';
  green_screen(front, back, 2, 1.5);
